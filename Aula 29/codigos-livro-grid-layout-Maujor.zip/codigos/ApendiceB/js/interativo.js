﻿	var container = document.getElementsByClassName("container")[0];
	var escolher =  document.getElementById("escolher");